<?php
/**
 * 
 */
class About extends CI_controller
{
	
	function index()
	{
		$this->load->view("about");
	}
}
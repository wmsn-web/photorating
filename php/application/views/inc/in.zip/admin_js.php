 <script src="admin_assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="admin_assets/vendors/chart.js/Chart.min.js"></script>
    <script src="admin_assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- End plugin js for this page -->
    <script src="admin_assets/vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="admin_assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <!-- inject:js -->
    <script src="admin_assets/js/off-canvas.js"></script>
    <script src="admin_assets/js/hoverable-collapse.js"></script>
    <script src="admin_assets/js/misc.js"></script>
    <script src="admin_assets/js/settings.js"></script>
    <script src="admin_assets/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="admin_assets/js/dashboard.js"></script>
    <script src="admin_assets/js/data-table.js"></script>
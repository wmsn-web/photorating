<?php

foreach($datafrnd as $row){

	echo $row['authemail']."<br>";
}

?>